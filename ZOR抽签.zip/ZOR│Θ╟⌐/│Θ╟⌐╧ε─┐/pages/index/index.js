// index.js
const app = getApp();
wx.cloud.init({env:"chouqian-7g0hcmvn12dfc2e8",traceUser:true})
const db=wx.cloud.database()
Page({
  data: {
    
    // 返回键显示
    isBack:false,
    openid:'nixx',
    hasUserInfo:false,
    userInfo:{avatarUrl:'"/images/avatar.png',name:'nixx'},
    inRoom:false,
    enterRoom:false,
    createRoom:false,
    // pickerData
    range:[1,2,3],
    range1:[1,2,3],
    index:0,
    index1:0,
    // 发送给服务器的数据
    totalPeopleNum:1,
    chosenNum:1,
    roomId:0
  },onLoad(options){
      //  分享数据处理
      const that=this
  if(options.share){
    let roomId=options.roomId
    console.log(options);
    that.setData({enterRoom:true,isBack:true,roomId:Number(roomId)})
    that.enterRoom()
  }
    var arr=new Array()
    for(var i=1;i<100;i++){
      arr.push(i)
    }
    this.setData({range:arr})

  },
  onShow() {
    
    const that=this
    
    wx.getStorage({
      key:'userInfo',
      success:(res)=>{
        console.log('userinfo',res);
        if(JSON.stringify(res.userInfo)!=='{}'){
          that.setData({userInfo:res.data,
            hasUserInfo:true
          })
      
        }
      }
    }
    )
  },
  changeTotalNum(e){
    this.setData({index:e.detail.value,totalPeopleNum:this.data.range[e.detail.value]})
    var arr=new Array()
    for(var i=1;i<(this.data.totalPeopleNum+1);i++){
      arr.push(i)
    }
    this.setData({range1:arr})
  },
  changeChosenNum(e){
    this.setData({index1:e.detail.value,chosenNum:this.data.range1[e.detail.value]})
  },
  createRoom(){
    this.setData({createRoom:true,isBack:true})
  },
  // 确认创建房间，向云函数提交申请
  async createEnsure(){
    const that=this
    var roomData={totalNum:this.data.totalPeopleNum,
                  chosenNum:this.data.chosenNum,
                  host_openid:this.data.openid,
                  roomId:100000,
                  luckyNum:[]  
              }
  
  //  生成房间号
   let result=''
   while(!result.data){
    var  roomId=Math.floor(Math.random()*1000000)
    result= await db.collection("roomData").where({roomId:roomId}).get()
   }
   roomData.roomId=roomId
   that.setData({roomId:roomData.roomId})
   //向服务器传递个人信息
  // 中奖用户的数组下标luckyNum
  
  // for(var i=0;i<roomData.chosenNum;i++){
  //   let random=Math.floor(Math.random()*roomData.totalNum)
  //   for(var j=0;j<roomData.luckyNum.length;j++){
  //     if(roomData.luckyNum[j]!=random){

  //     }
  //   }
  //   roomData.luckyNum.push(random)
  // }
  let i=0
  let chosenNum=roomData.chosenNum
  let arr= roomData.luckyNum
  while(i<chosenNum){
    let random=Math.floor(Math.random()*roomData.totalNum)
    let flag=true
    let j=0
    for(j in arr){
      if(arr[j]==random){
        flag=false
        break
      }
    }
   if (flag) {
     arr.push(random)
     i++
   }
  }
  roomData.luckyNum=arr
  console.log(roomData.luckyNum);
  //  提交房间信息
  db.collection("roomData").add({data:{...roomData},
  success(res){
    // 保存房间号
    wx.setStorageSync('roomId', that.data.roomId)
    wx.navigateTo({
      url: '/pages/lucky-table/lucky-table',
    })
  },
  fail(err){
  console.log(err)
  }})
  
  let userInfo=this.data.userInfo
  db.collection("userData").add({data:{userData:[{avatarUrl:userInfo.avatarUrl,name:userInfo.nickName,isHost:true,isReady:false}],roomId:roomId},
  success:(res)=>{
    console.log('创建userData成功',res);
  }})
  
  

  },
  // 点击返回键可返回主页
  getBack(){
    this.setData({isBack:false,createRoom:false,inRoom:false,enterRoom:false})
  }
  ,
  // 加入房间
  enterRoom(){
    const that=this
    if(this.data.enterRoom){
      that.setData({isBack:true})
      db.collection("roomData").where({roomId:that.data.roomId}).get().
      then(function(res){
        console.log(res);
        if(res.data[0]){
          that.setData({inRoom:true,isBack:true})
          wx.setStorageSync('roomId',that.data.roomId)
         console.log(wx.getStorageSync('userInfo')); 
          console.log('成功加入房间',res);
          wx.navigateTo({
            url: '/pages/lucky-table/lucky-table',
          })
        }else{
          console.log('房间号不存在！');
        }
      }).catch(function(err){
        console.log(err,'加入房间失败，请检查网络是否可用');
      })
      
    }else{
      this.setData({enterRoom:true,isBack:true})
    }
  },
  inputRoomId(e){
    this.setData({roomId:Number(e.detail.value)})
    console.log( e.detail.value);
  },
  getUserProfile(e){
    const that=this
    wx.getUserProfile({
     desc: 'desc',
     success(res){
       that.setData({userInfo:res.userInfo,hasUserInfo:true}
       )
       wx.setStorageSync('userInfo',res.userInfo)
     }
   })
   
  },
  onShareAppMessage(){
    return{
      "title":'1504D抽签助手',
      "imageUrl":'/images/stiches.jpg',
    }
  }
})