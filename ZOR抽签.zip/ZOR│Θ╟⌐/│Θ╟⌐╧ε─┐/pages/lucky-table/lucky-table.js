// index.js
const app = getApp();
wx.cloud.init()
const db=wx.cloud.database()
Page({
  data: {
    timer_index:'',
    timer_refresh:'',
    source:40,
    // 弹出层显示
    showModal:false,
    infoGotten:false,
    isAllReady:false,
    isReady:false,
    myName:'xiaofang',
    // 转盘
    // 转盘显示
    showTable:true,
    blocks: [{ padding: '13px', background: '#068DEF' }],
    prizes: [
      { fonts: [{ text: '0', top: '10%' ,fontColor:'white'}], background: '#e9e8fe' }
    ],
    buttons: [
      { radius: '50px', background: '#17B1C0' },
      { radius: '45px', background: '#E3E3E3' },
      {
        radius: '40px', background: '#15ADC7',
        pointer: true,
        fonts: [{ text: '开始\n抽签', top: '-20px',fontColor:'white' }]
      },
    ],
    // 房间号
    roomId:10086,
    // 中奖和没中奖的用户信息，
    chosenList:[],
    unchosenList:[],
    // 所有用户信息
    userData:[{
    avatar:"/images/avatar.png",
    name:'zoratt',
    },{
      avatar:"/images/avatar.png",
      name:'zoratt'
      },
      {
        avatar:"/images/avatar.png",
        name:'zoratt',
        
        },{
          avatar:"/images/avatar.png",
          name:'zoratt'
          },
          {
            avatar:"/images/avatar.png",
            name:'zoratxxxxt'
            },
            {
              avatar:"/images/avatar.png",
              name:'zoratt'
              },{
                avatar:"/images/avatar.png",
                name:'zoratt'
                },{
                  avatar:"/images/avatar.png",
                  name:'zoratt'
                  },{
                    avatar:"/images/avatar.png",
                    name:'zoratt'
                    },{
                      avatar:"/images/avatar.png",
                      name:'zoratt'
                      },{
                        avatar:"/images/avatar.png",
                        name:'zoratt'
                        },{
                          avatar:"/images/avatar.png",
                          name:'zoratt'
                          }
                        ],
      // 转盘分隔块数
      totalNum:6,
      chosenNum:1 ,
       //  是否被选中标志位
       isChosen:0,
       luckyNum:1,
      // 大奖品下标
       specialPrizes:[],
      //  转盘索引
      index:0,
  },
  onLoad(options){
    var that=this
    
    // 获取本地roomId
      try {
        that.setData({myName:wx.getStorageSync('userInfo').nickName,roomId:Number(wx.getStorageSync('roomId'))})
      } catch (error) {
        console.log('获取用户名失败，请授权获取')
      }
    // 将个人信息上传至服务器
     // 成功加入房间后将个人信息传给服务器
     db.collection('userData').where({roomId:Number(wx.getStorageSync('roomId'))}).get().
     then(function(res){
      console.log(res,that.data.roomId,typeof that.data.roomId);
       var userArr=res.data[0].userData
       var userInfo=wx.getStorageSync('userInfo')
       var exist=false
      //  判断一下是否存在该用户
      var i
      for(i in userArr){
        if(userArr[i].name==userInfo.nickName){
          exist=true
          break
        }
      }
       if(userInfo&&!exist){
         userArr.push({avatarUrl:userInfo.avatarUrl,name:userInfo.nickName,isReady:false,isHost:false})
         db.collection('userData').where({roomId:that.data.roomId}).update({
           data:{userData:userArr},
           success:()=>{
           console.log('成功将个人信息添加至服务器',userArr);
           }
         })
       }else{
         console.log('未获取到用户名称或已加入房间',exist);
       }
       
     })
    // 获取中奖人数和中奖总人数
    db.collection('roomData').where({roomId:this.data.roomId}).get().then(function(res){
      that.setData({totalNum:res.data[0].totalNum,chosenNum:res.data[0].chosenNum})
    }).then(function(){
 // 生成抽签数据
 var range=Math.floor(that.data.totalNum/that.data.chosenNum)
 var prizes=[]
 var chosenNum=that.data.chosenNum
 var specialPrizes=[]
 for(var i=0;i<that.data.totalNum;i++){
   var template={ fonts: [{ text: '', top: '10%' ,fontColor:'white'}], background: '#E3E3E3' }
   if(i%range==0&&chosenNum){
     specialPrizes.push(i)
     that.setData({specialPrizes:specialPrizes})
     template.fonts[0].text=chosenNum--
     template.background='#FFCC00'
   }
   prizes.push(template)
 }
 that.setData({prizes:prizes})
    }).catch(function(err){console.log('获取中奖信息失败',err);})

    
    that.refresh()
    const getReady=that.refresh
    that.setData({timer_refresh:setInterval(getReady,4000)}) 
  },
  refresh(){
    const that=this
// 资源耗尽不再请求
    that.setData({source:Number(that.data.source)-1})
    console.log(that.data.source);
    if(!that.data.source){
      clearInterval(that.data.timer_refresh)
    }
    // 准备开始刷新和获取用户头像和判断用户是否全部准备
    const getReady=function (){
      db.collection('userData').where({roomId:that.data.roomId}).get().then(function(res){
        that.setData({userData:res.data[0].userData})
        // 判断用户是否全部都准备
        var i=0
        var isAllReady=true
        var userData=res.data[0].userData
        var totalNum=that.data.totalNum
        if (!(userData.length==totalNum)) {
          isAllReady=false
          console.log('判断1',totalNum);
        }
        for(i in userData){
          if(!userData[i].isReady){
            console.log('判断2');
            isAllReady=false
            break
          }
        }
       that.setData({isAllReady:isAllReady})
      }).catch(function(err){console.log(err);})
    }
    getReady()
  }
  ,
  onShow(){
    const that=this
    that.setData({timer_index:setInterval(that.getIndexInfo,6000)})
  },
  onReady(){
    this.refresh()
  },
  getReady(){
    var that=this
    var userArr
    // 使用名字取出下标
    db.collection("userData").where({roomId:this.data.roomId}).get().then(function(res){
      var i=0
      userArr=res.data[0].userData
      console.log('uarr',userArr);
      for(i in userArr){
        if(userArr[i].name==that.data.myName){
          userArr[i].isReady=true
          that.setData({isReady:true})
        }
      }
      // 刷新一次
      that.setData({userData:userArr})
      console.log(userArr);
    }).then(function(){
    // 使用下标修改准备状态
    db.collection("userData").where({roomId:that.data.roomId}).update({
      data:{ userData:userArr}
        })
    })
  },


  // 获取中奖下标信息
  getIndexInfo(){
  const that=this
  // 资源耗尽不再请求
  that.setData({source:Number(that.data.source)-1})
  if(!that.data.source){
    clearInterval(that.data.timer_index)
  }
  if(this.data.isAllReady){
    clearInterval(that.data.timer_refresh)
 //获取中奖信息 
 db.collection('roomData').where({roomId:that.data.roomId}).get().then(
  function(res){
   that.setData({luckyNum:res.data[0].luckyNum}) 
  }
).then(function(){
  let i=0
let specialPrizes=that.data.specialPrizes
let luckyNum=that.data.luckyNum
let userData=that.data.userData
let myName=that.data.myName
// 判断中奖和不中奖的人有哪些
var chosenList=[]
var unchosenList=[]
for(i in luckyNum){
  chosenList.push(userData[luckyNum[i]]) 
}
i=0
for(i in userData){
  let j=0
  let flag=false
  for(j in luckyNum){
    if(userData[luckyNum[j]]==userData[i]){
      flag=true
    }
  }
 if (!flag) {
   unchosenList.push(userData[i])
 }
}
that.setData({chosenList:chosenList,unchosenList:unchosenList})
// 判断我自己是否中奖
i=0
for(i in luckyNum){
  if (userData[luckyNum[i]].name==myName) {
    // 中奖的获得中奖下标之一
    that.setData({isChosen:true})
    var index=specialPrizes[i]
    that.setData({index:index,infoGotten:true})
    console.log('中奖了！',index);
    break;
  }
  else if(i==(luckyNum.length-1)){
    // 获得不中奖下标之一
    console.log('没中奖');
    var qwq=0
    while(true){
      var flag=true
      for(let i=0;i<specialPrizes.length;i++){
        if (specialPrizes[i]==qwq) {
          flag=false
          break
        }
      }
      if (flag) {
        console.log('qwq',qwq);
        that.setData({index:qwq,infoGotten:true})
        break
      }
      qwq++
    }
  }
}

  clearInterval(that.data.timer_index)
})
  }
},


  start () {
    const that=this
    if(this.data.isAllReady){
// 获取抽奖组件实例
const child = this.selectComponent('#myLucky')
// 调用play方法开始旋转
child.$lucky.play()
// 用定时器模拟请求接口
setTimeout(() => {
  // 3s 后得到中奖索引 (假设抽到第0个奖品)
  const index = that.data.index
  // 调用stop方法然后缓慢停止
  child.$lucky.stop(index)
}, 3000)
// 显示弹出层
setTimeout(() => {
  that.showModal()
}, 6000)   
// 停止请求
clearInterval(that.data.timer_index)
clearInterval(that.data.timer_refresh)
} 
  },
  end (event) {
    const index = this.data.index
    // 中奖奖品详情
    console.log(index)
  },
  // 回到主页
  getBack(){
    wx.navigateTo({
      url: '/pages/index',
    })
  },
  // 弹出框
  showModal() {
    this.setData({
      showModal: true,
      showTable:false
    })
  },
  // 隐藏弹出层
  hideModal(){
    this.setData({
      showModal: false,
      showTable:true
    })
  }
  // 带参数分享房间
  ,
  onShareAppMessage(){
    const that =this
    return{
      "title":'点击进入抽签',
      "imageUrl":'/images/share1.png',
      "path":'/pages/index/index?'+'roomId='+that.data.roomId+'&share=true'
    }
  }
})